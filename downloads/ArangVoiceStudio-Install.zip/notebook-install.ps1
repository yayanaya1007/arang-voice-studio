﻿$ErrorActionPreference = 'Stop'
$arangPayloadRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$arangTesting = [bool]$env:ARANG_INSTALL_TEST_DIR
$arangInstallDirectory = if ($arangTesting) {$env:ARANG_INSTALL_TEST_DIR} else {Join-Path $env:LOCALAPPDATA 'ArangVoiceStudio'}
if (!$arangTesting) {
    $arangKnownInstall = Test-Path -LiteralPath (Join-Path $arangInstallDirectory 'desktop_launcher.py')
    $arangRegistered = Get-ItemProperty -LiteralPath 'HKCU:\Software\ArangVoiceStudio' -ErrorAction SilentlyContinue
    if ($arangRegistered.InstallDirectory -and (Test-Path -LiteralPath $arangRegistered.InstallDirectory)) {
        $arangInstallDirectory = $arangRegistered.InstallDirectory
        $arangKnownInstall = $true
    } else {
        $arangCandidates = @('C:\ArangVoice',(Join-Path $env:USERPROFILE 'ArangVoice'),(Join-Path ([Environment]::GetFolderPath('Desktop')) 'ArangVoice'))
        foreach($arangCandidate in $arangCandidates) {
            if ((Test-Path -LiteralPath (Join-Path $arangCandidate 'desktop_launcher.py')) -and (Test-Path -LiteralPath (Join-Path $arangCandidate 'data'))) {$arangInstallDirectory=$arangCandidate;$arangKnownInstall=$true;break}
        }
    }
    $arangProbe = New-Object System.Net.Sockets.TcpClient
    try {
        $arangConnect = $arangProbe.ConnectAsync('127.0.0.1',8787)
        if ($arangConnect.Wait(500) -and $arangProbe.Connected) {
            Add-Type -AssemblyName System.Windows.Forms
            [System.Windows.Forms.MessageBox]::Show('이 컴퓨터의 아랑 보이스 실행 창을 먼저 종료한 뒤 설치 파일을 다시 실행해 주세요. 녹음과 작업 파일은 그대로 보관됩니다.','아랑 보이스 업데이트') | Out-Null
            exit 0
        }
    } catch {} finally {$arangProbe.Dispose()}
    if (!$arangKnownInstall) {
        Add-Type -AssemblyName System.Windows.Forms
        New-Item -ItemType Directory -Path $arangInstallDirectory -Force | Out-Null
        $arangDefaultDirectory = $arangInstallDirectory
        $arangFolder = New-Object System.Windows.Forms.FolderBrowserDialog
        $arangFolder.Description = '기존 아랑 보이스 폴더가 있으면 그 폴더를 선택하세요. 처음 설치하면 그대로 확인을 누르세요.'
        $arangFolder.SelectedPath = $arangInstallDirectory
        if ($arangFolder.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {exit 0}
        $arangInstallDirectory = $arangFolder.SelectedPath
        if ($arangInstallDirectory -ne $arangDefaultDirectory -and !(Test-Path -LiteralPath (Join-Path $arangInstallDirectory 'desktop_launcher.py'))) {
            [System.Windows.Forms.MessageBox]::Show('선택한 폴더에서 기존 아랑 보이스 앱을 찾지 못했어요. 설치 파일을 다시 실행해 기존 아랑 폴더를 선택해 주세요.','아랑 보이스 업데이트') | Out-Null
            exit 0
        }
    }
}
New-Item -ItemType Directory -Path $arangInstallDirectory -Force | Out-Null
$arangStaging = Join-Path ([System.IO.Path]::GetTempPath()) ('arang-install-'+[guid]::NewGuid().ToString('N'))
Expand-Archive -LiteralPath (Join-Path $arangPayloadRoot 'notebook-payload.zip') -DestinationPath $arangStaging
# The distributed ZIP never contains data/, models/, or private account files.
if ((Test-Path -LiteralPath (Join-Path $arangStaging 'data')) -or (Test-Path -LiteralPath (Join-Path $arangStaging 'models'))) {throw '설치 파일에 허용되지 않은 자료가 있습니다.'}
Get-ChildItem -LiteralPath $arangStaging -Force | ForEach-Object {Copy-Item -LiteralPath $_.FullName -Destination $arangInstallDirectory -Recurse -Force}
if ($arangTesting) {Write-Output ('Isolated install files copied: '+$arangInstallDirectory);exit 0}
New-Item -Path 'HKCU:\Software\ArangVoiceStudio' -Force | Out-Null
New-ItemProperty -Path 'HKCU:\Software\ArangVoiceStudio' -Name InstallDirectory -Value $arangInstallDirectory -PropertyType String -Force | Out-Null
$arangShortcut=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) '아랑 보이스 스튜디오.lnk'))
$arangShortcut.TargetPath=Join-Path $arangInstallDirectory 'Arang-Start.cmd'
$arangShortcut.WorkingDirectory=$arangInstallDirectory
$arangShortcut.Save()
Start-Process -FilePath (Join-Path $arangInstallDirectory 'Arang-Start.cmd') -WorkingDirectory $arangInstallDirectory
