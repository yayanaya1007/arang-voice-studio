"""User-supplied voice APIs. No shared key or environment-key fallback."""
from __future__ import annotations

import base64
import io
import json
import re
import uuid
from pathlib import Path

import httpx
import numpy as np
import soundfile as sf

OPENAI_VOICES = ["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx",
                 "sage", "shimmer", "verse", "marin", "cedar"]
DEFAULT_MODELS = {"openai": "gpt-4o-mini-tts", "gemini": "gemini-3.8-flash-lite-tts",
                  "elevenlabs": "eleven_multilingual_v2"}


async def api_request(settings: dict, method: str, url: str, **kwargs) -> httpx.Response:
    key, provider = settings.get("key"), settings.get("provider")
    if not key:
        raise ValueError("내 작업실에 API 키를 먼저 연결해 주세요.")
    header = {"openai": {"Authorization": "Bearer "+key}, "gemini": {"x-goog-api-key": key},
              "elevenlabs": {"xi-api-key": key}}.get(provider)
    if not header:
        raise ValueError("지원하는 API 서비스를 선택해 주세요.")
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(180, connect=15), trust_env=False) as client:
            response = await client.request(method, url, headers=header, **kwargs)
    except httpx.TimeoutException as exc:
        raise ValueError("API 응답이 늦어 요청을 중단했어요. 잠시 후 다시 시도해 주세요.") from exc
    except httpx.HTTPError as exc:
        raise ValueError("선택한 API 서비스에 연결하지 못했어요.") from exc
    if not response.is_success:
        if response.status_code in (401, 403):
            raise ValueError("내 API 키와 음성 기능 접근 권한을 확인해 주세요. (HTTP %s)" % response.status_code)
        if response.status_code == 429:
            raise ValueError("내 API 계정의 사용 한도·크레딧 또는 요청 제한을 확인해 주세요. (HTTP 429)")
        raise ValueError("API가 요청을 처리하지 못했어요. 음성·모델 설정을 확인해 주세요. (HTTP %s)" % response.status_code)
    return response


async def available_voices(settings: dict) -> list[dict[str, str]]:
    provider = settings.get("provider")
    if provider == "openai":
        await api_request(settings, "GET", "https://api.openai.com/v1/models")
        return [{"id": name, "name": name} for name in OPENAI_VOICES]
    if provider == "gemini":
        voices, token, seen = [], None, set()
        while True:
            response = await api_request(settings, "GET", "https://generativelanguage.googleapis.com/v1beta/voices",
                params={"page_token": token} if token else {})
            page = response.json()
            voices.extend({"id": entry["id"], "name": entry.get("display_name") or entry["id"]}
                          for entry in page.get("voices", []) if entry.get("id"))
            token = page.get("next_page_token")
            if not token:
                break
            if token in seen:
                raise ValueError("API 음성 목록의 다음 페이지를 읽지 못했어요.")
            seen.add(token)
        if not voices:
            raise ValueError("내 API에서 사용할 음성 목록을 찾지 못했어요.")
        return voices
    if provider == "elevenlabs":
        voices, token, seen = [], None, set()
        while True:
            params = {"page_size": 100}
            if token:
                params["next_page_token"] = token
            response = await api_request(settings, "GET", "https://api.elevenlabs.io/v2/voices", params=params)
            page = response.json()
            voices.extend({"id": entry["voice_id"], "name": entry.get("name", entry["voice_id"])}
                          for entry in page.get("voices", []) if entry.get("voice_id"))
            token = page.get("next_page_token")
            if not page.get("has_more"):
                break
            if not token or token in seen:
                raise ValueError("API 음성 목록의 다음 페이지를 읽지 못했어요.")
            seen.add(token)
        if not voices:
            raise ValueError("내 API 계정에 사용할 수 있는 음성이 없어요.")
        return voices
    raise ValueError("내 API 서비스를 먼저 선택해 주세요.")


async def generate_speech(settings: dict, text: str, voice: str, destination: Path) -> Path:
    provider = settings.get("provider")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", voice):
        raise ValueError("내 API에서 사용할 음성을 먼저 선택해 주세요.")
    model = settings.get("model") or DEFAULT_MODELS.get(provider)
    if not model or not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", model):
        raise ValueError("API 모델 설정을 확인해 주세요.")
    raw_pcm = False
    rate = 24000
    if provider == "openai":
        if voice not in OPENAI_VOICES:
            raise ValueError("선택한 OpenAI 음성을 확인해 주세요.")
        response = await api_request(settings, "POST", "https://api.openai.com/v1/audio/speech", json={
            "model": model, "input": text, "voice": voice, "response_format": "wav"})
        content = response.content
    elif provider == "gemini":
        config = {"responseModalities": ["AUDIO"]}
        if model.startswith(("gemini-2.5", "gemini-3.1")):
            config["speechConfig"] = {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}
        else:
            config["speechConfig"] = {"voiceConfig": {"voice": voice}}
            config["responseFormat"] = {"audio": {"mimeType": "AUDIO_L16", "sampleRate": 24000}}
        response = await api_request(settings, "POST",
            f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
            json={"contents": [{"role": "user", "parts": [{"text": text}]}], "generationConfig": config})
        try:
            parts = response.json()["candidates"][0]["content"]["parts"]
            inline = next(part["inlineData"] for part in parts if part.get("inlineData"))
            content = base64.b64decode(inline["data"], validate=True)
            raw_pcm = not content.startswith(b"RIFF")
            match = re.search(r"rate=(\d+)", inline.get("mimeType", ""))
            if match:
                rate = int(match.group(1))
        except (KeyError, IndexError, StopIteration, ValueError) as exc:
            raise ValueError("API에서 음성 파일을 받지 못했어요. 모델의 음성 생성 지원을 확인해 주세요.") from exc
    elif provider == "elevenlabs":
        response = await api_request(settings, "POST", f"https://api.elevenlabs.io/v1/text-to-speech/{voice}",
            params={"output_format": "pcm_24000"}, json={"text": text, "model_id": model})
        content, raw_pcm = response.content, True
    else:
        raise ValueError("내 API 서비스를 먼저 선택해 주세요.")
    if not content or len(content) > 128*1024*1024:
        raise ValueError("API 음성 파일이 비어 있거나 너무 커요.")
    destination.mkdir(parents=True, exist_ok=True)
    output = destination/f"{uuid.uuid4().hex}.wav"
    if raw_pcm:
        if len(content) % 2 or not 8000 <= rate <= 192000:
            raise ValueError("API 음성 파일 형식을 읽지 못했어요.")
        samples = np.frombuffer(content, dtype="<i2")
        sf.write(output, samples, rate, subtype="PCM_16")
    else:
        try:
            info = sf.info(io.BytesIO(content))
            if info.frames == 0 or info.format != "WAV":
                raise ValueError("Invalid WAV")
        except (RuntimeError, ValueError) as exc:
            raise ValueError("API 응답에서 재생 가능한 WAV를 찾지 못했어요.") from exc
        output.write_bytes(content)
    output.with_suffix(".json").write_text(json.dumps({"provider": provider, "model": model,
        "voice": voice, "text": text, "engine": "personal-api", "voiceAltered": False}, ensure_ascii=False, indent=2), encoding="utf-8")
    return output
