"""Private workspaces; shared voice references never contain personal API keys."""
from __future__ import annotations

import ctypes
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time
import uuid
from pathlib import Path


def atomic_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}-{uuid.uuid4().hex}.tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def protect_secret(data: bytes, *, decrypt: bool = False) -> bytes:
    """Windows DPAPI, bound to the Windows account running the application."""
    if os.name != "nt":
        raise RuntimeError("이 서버의 보안 저장소를 사용할 수 없어요. API 키는 저장하지 않았습니다.")
    from ctypes import wintypes

    class Blob(ctypes.Structure):
        _fields_ = [("size", wintypes.DWORD), ("data", ctypes.POINTER(ctypes.c_ubyte))]

    buffer = ctypes.create_string_buffer(data)
    source = Blob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
    result = Blob()
    crypt = ctypes.WinDLL("crypt32", use_last_error=True)
    if decrypt:
        operation = crypt.CryptUnprotectData
        operation.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p,
                              ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        ok = operation(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(result))
    else:
        operation = crypt.CryptProtectData
        operation.argtypes = [ctypes.POINTER(Blob), wintypes.LPCWSTR, ctypes.c_void_p,
                              ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        ok = operation(ctypes.byref(source), "Arang private API settings", None, None, None, 1, ctypes.byref(result))
    if not ok:
        raise RuntimeError("API 키 보안 저장소를 열지 못했어요.")
    try:
        return ctypes.string_at(result.data, result.size)
    finally:
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.LocalFree.argtypes = [ctypes.c_void_p]
        kernel.LocalFree(ctypes.cast(result.data, ctypes.c_void_p))


class WorkspaceStore:
    def __init__(self, root: Path, secret: str, owner_code: str):
        self.root, self.secret, self.owner_code = root, secret.encode(), owner_code
        self.lock = threading.RLock()

    def digest(self, value: str) -> str:
        return hmac.new(self.secret, value.encode(), hashlib.sha256).hexdigest()

    def registry(self) -> dict:
        path = self.root/'accounts.json'
        if not path.exists():
            return {"accounts": {"owner": {"id": "owner", "name": "내 작업실", "role": "owner",
                     "codeHash": self.digest("login:"+self.owner_code)}}, "invites": {}}
        data = json.loads(path.read_text(encoding="utf-8"))
        if "owner" not in data.get("accounts", {}):
            raise ValueError("작업실 목록을 읽지 못했어요.")
        return data

    def account(self, workspace_id: str) -> dict:
        with self.lock:
            result = self.registry()["accounts"].get(workspace_id)
            if not result:
                raise ValueError("작업실을 찾지 못했어요.")
            return {key: result[key] for key in ("id", "name", "role")}

    def authenticate(self, code: str) -> str | None:
        digest = self.digest("login:"+code.strip())
        with self.lock:
            for identity, account in self.registry()["accounts"].items():
                password = account.get("passwordHash")
                if password:
                    salt, expected = password.split(":", 1)
                    actual = hashlib.scrypt(code.encode(), salt=bytes.fromhex(salt), n=16384, r=8, p=1, dklen=32).hex()
                    if secrets.compare_digest(actual, expected):
                        return identity
                elif secrets.compare_digest(digest, account.get("codeHash", "")):
                    return identity
        return None

    def set_password(self, identity: str, password: str) -> None:
        if not 8 <= len(password) <= 128:
            raise ValueError("비밀번호는 8자 이상 128자 이하로 정해 주세요.")
        salt = secrets.token_bytes(16)
        derived = hashlib.scrypt(password.encode(), salt=salt, n=16384, r=8, p=1, dklen=32).hex()
        with self.lock:
            data = self.registry()
            if identity not in data["accounts"]:
                raise ValueError("작업실을 찾지 못했어요.")
            account = data["accounts"][identity]
            account["passwordHash"] = salt.hex()+":"+derived
            account.pop("codeHash", None)
            data["recovery"] = {k:v for k,v in data.get("recovery", {}).items() if v["identity"] != identity}
            atomic_json(self.root/'accounts.json', data)

    def folder(self, workspace_id: str) -> Path:
        if not re.fullmatch(r"owner|[a-f0-9]{32}", workspace_id):
            raise ValueError("잘못된 작업실 주소예요.")
        self.account(workspace_id)
        folder = self.root/workspace_id
        folder.mkdir(parents=True, exist_ok=True)
        return folder

    def invite(self) -> str:
        token = secrets.token_urlsafe(32)
        with self.lock:
            data = self.registry()
            data["invites"] = {key: expiry for key, expiry in data["invites"].items() if expiry > time.time()}
            data["invites"][self.digest("invite:"+token)] = int(time.time()) + 7*24*3600
            atomic_json(self.root/'accounts.json', data)
        return token

    def invite_valid(self, token: str) -> bool:
        with self.lock:
            return self.registry()["invites"].get(self.digest("invite:"+token), 0) > time.time()

    def join(self, token: str, name: str) -> tuple[str, str]:
        name = " ".join(name.split()).strip()
        if not 1 <= len(name) <= 40:
            raise ValueError("작업실 이름을 1~40자로 입력해 주세요.")
        with self.lock:
            data = self.registry()
            key = self.digest("invite:"+token)
            if data["invites"].get(key, 0) <= time.time():
                raise ValueError("초대 링크가 만료됐거나 이미 사용됐어요.")
            identity, code = uuid.uuid4().hex, secrets.token_urlsafe(18)
            data["accounts"][identity] = {"id": identity, "name": name, "role": "member",
                                           "codeHash": self.digest("login:"+code)}
            del data["invites"][key]
            atomic_json(self.root/'accounts.json', data)
        return identity, code

    def bridge_token(self, identity: str) -> str:
        self.account(identity)
        return identity+"."+self.digest("bridge:"+identity)

    def members(self) -> list[dict]:
        with self.lock:
            return [{"id": entry["id"], "name": entry["name"]}
                    for entry in self.registry()["accounts"].values() if entry.get("role") == "member"]

    def recovery_link(self, identity: str) -> str:
        """A one-use, 24-hour login recovery grant for an existing workspace."""
        self.account(identity)
        token = secrets.token_urlsafe(32)
        with self.lock:
            data = self.registry()
            recovery = {key: value for key, value in data.get("recovery", {}).items()
                        if value["expires"] > time.time() and value["identity"] != identity}
            recovery[self.digest("recovery:"+token)] = {"identity": identity, "expires": int(time.time())+24*3600}
            data["recovery"] = recovery
            atomic_json(self.root/'accounts.json', data)
        return token

    def recovery_account(self, token: str) -> dict | None:
        with self.lock:
            grant = self.registry().get("recovery", {}).get(self.digest("recovery:"+token))
            if not grant or grant["expires"] <= time.time():
                return None
            return self.account(grant["identity"])

    def reset_code(self, identity: str) -> str:
        with self.lock:
            data = self.registry()
            if identity not in data["accounts"]:
                raise ValueError("작업실을 찾지 못했어요.")
            code = secrets.token_urlsafe(18)
            data["accounts"][identity]["codeHash"] = self.digest("login:"+code)
            data["accounts"][identity].pop("passwordHash", None)
            data["recovery"] = {key: value for key, value in data.get("recovery", {}).items() if value["identity"] != identity}
            atomic_json(self.root/'accounts.json', data)
            return code

    def recover(self, token: str) -> tuple[str, str]:
        with self.lock:
            data = self.registry()
            key = self.digest("recovery:"+token)
            grant = data.get("recovery", {}).get(key)
            if not grant or grant["expires"] <= time.time():
                raise ValueError("이미 사용했거나 만료된 복구 링크예요.")
            identity, code = grant["identity"], secrets.token_urlsafe(18)
            if identity not in data["accounts"]:
                raise ValueError("복구할 작업실을 찾지 못했어요.")
            data["accounts"][identity]["codeHash"] = self.digest("login:"+code)
            data["accounts"][identity].pop("passwordHash", None)
            del data["recovery"][key]
            atomic_json(self.root/'accounts.json', data)
            return identity, code

    def bridge_identity(self, token: str) -> str | None:
        if secrets.compare_digest(token, self.owner_code):
            owner = self.registry()["accounts"]["owner"]
            return "owner" if not owner.get("passwordHash") and secrets.compare_digest(owner.get("codeHash", ""), self.digest("login:"+token)) else None
        identity, separator, digest = token.partition(".")
        if separator and secrets.compare_digest(digest, self.digest("bridge:"+identity)):
            try:
                self.account(identity)
                return identity
            except ValueError:
                pass
        return None

    def draft(self, identity: str) -> dict:
        path = self.folder(identity)/'draft.json'
        with self.lock:
            return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"text": "", "profileId": ""}

    def save_draft(self, identity: str, draft: dict) -> None:
        with self.lock:
            atomic_json(self.folder(identity)/'draft.json', draft)

    def settings(self, identity: str) -> dict:
        path = self.folder(identity)/'api-settings.dpapi'
        with self.lock:
            return json.loads(protect_secret(path.read_bytes(), decrypt=True)) if path.exists() else {}

    def save_settings(self, identity: str, settings: dict) -> None:
        path = self.folder(identity)/'api-settings.dpapi'
        encrypted = protect_secret(json.dumps(settings).encode())
        with self.lock:
            temporary = path.with_name(f".{path.name}-{uuid.uuid4().hex}.tmp")
            temporary.write_bytes(encrypted)
            os.replace(temporary, path)

    def clear_settings(self, identity: str) -> None:
        with self.lock:
            (self.folder(identity)/'api-settings.dpapi').unlink(missing_ok=True)
