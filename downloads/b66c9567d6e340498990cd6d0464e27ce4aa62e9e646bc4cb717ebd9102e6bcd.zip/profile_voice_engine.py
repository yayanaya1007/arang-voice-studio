"""Local voice cloning for the user's saved non-Arang voice profiles."""

from __future__ import annotations

import os
import sys
import threading
from pathlib import Path
from typing import Any

import numpy as np
import soundfile as sf

_lock = threading.Lock()
_model: Any | None = None
_prompts: dict[tuple[str, int], Any] = {}


def _engine(app_root: Path):
    global _model
    if _model is not None:
        return _model
    data_root = Path(os.getenv("ARANG_DATA_DIR", str(app_root / "data"))).resolve()
    model_root = data_root / "private-model/models/Qwen3-TTS-12Hz-0.6B-Base"
    if not (model_root / "model.safetensors").is_file():
        raise RuntimeError("저장된 목소리용 로컬 모델을 찾지 못했어요.")
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    for import_root in (data_root / "private-model/qwen-runtime", data_root / "private-model/vendor", app_root / "runtime"):
        value = str(import_root)
        if value in sys.path:
            sys.path.remove(value)
        sys.path.insert(0, value)
    import torch
    from qwen_tts import Qwen3TTSModel

    device = "cpu"
    dtype = torch.float32
    if torch.cuda.is_available():
        try:
            free_bytes, _ = torch.cuda.mem_get_info(0)
            if free_bytes >= 4 * 1024**3:
                device = "cuda:0"
                dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        except Exception:
            pass
    _model = Qwen3TTSModel.from_pretrained(
        str(model_root), device_map=device, dtype=dtype,
        attn_implementation="sdpa",
        local_files_only=True, trust_remote_code=False,
        use_safetensors=True, weights_only=True,
    )
    return _model


def synthesize_saved_profile(text: str, profile: dict[str, Any], app_root: Path, voice_dir: Path) -> tuple[np.ndarray, int, str]:
    audio_name = str(profile.get("audioFile", ""))
    reference_text = str(profile.get("referenceText", "")).strip()
    if not audio_name or Path(audio_name).name != audio_name or not reference_text:
        raise RuntimeError("목소리 원본이나 녹음 문구가 없습니다.")
    source = voice_dir / audio_name
    if not source.is_file():
        raise RuntimeError("저장된 목소리 원본을 찾지 못했어요.")

    with _lock:
        model = _engine(app_root)
        key = (str(profile["id"]), source.stat().st_mtime_ns)
        prompt = _prompts.get(key)
        if prompt is None:
            wave, rate = sf.read(source, dtype="float32", always_2d=False)
            if wave.ndim > 1:
                wave = wave.mean(axis=1)
            prompt = model.create_voice_clone_prompt(
                ref_audio=(np.asarray(wave, dtype=np.float32), rate), ref_text=reference_text,
            )
            _prompts[key] = prompt
        import torch
        torch.manual_seed(20261106 + sum(ord(c) for c in text))
        voices, sample_rate = model.generate_voice_clone(
            text=text, language="Korean", voice_clone_prompt=prompt,
            non_streaming_mode=True, do_sample=True,
            temperature=0.55, top_p=0.82, repetition_penalty=1.12,
            max_new_tokens=min(1536, max(256, len(text) * 12)),
        )
        output = np.asarray(voices[0], dtype=np.float32).reshape(-1)
        if output.size == 0 or not np.isfinite(output).all():
            raise RuntimeError("목소리 생성 결과가 비어 있거나 손상됐어요.")
        peak = float(np.max(np.abs(output)))
        if peak > 1.0:
            output = output / peak * 0.98
        return output, int(sample_rate), "saved-profile-qwen3-tts-0.6b-local"
