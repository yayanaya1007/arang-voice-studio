"""Unmodified official Qwen Base weights; all confirmed owner recordings are references.

This creates an in-memory clone prompt only. It never trains or writes model weights.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import threading
import re
import uuid
import numpy as np
import soundfile as sf
from profile_voice_engine import _engine

_lock=threading.Lock()
_cache={}
ENGINE_ID='official-qwen3-tts-0.6b-base-owner-references-v4-reading'

class TakeRejected(RuntimeError):
    """A generated take failed signal/contour checks, not a setup error."""

def reading_kind(text):
    core=text.strip().rstrip(' .!?。！？\"\'“”‘’…')
    if re.search(r'응\s*,?\s*먹었어',text) and '바빠' in text:
        return 'busy_firm'
    # Terminal Korean question endings, not question marks inside a quoted title.
    if re.search(r'(까요|나요|습니까|입니까|인가요|했나요)$',core):
        return 'question'
    if re.search(r'(다|요|죠|게|어)$',core):
        return 'declarative'
    return 'context_uncertain'

def reading_plan(text,preset='calm_contextual'):
    units=[]
    for paragraph in re.split(r'\n+',text.strip()):
        parts=[paragraph] if reading_kind(paragraph)=='busy_firm' else re.split(r'(?<=[.!?。！？])\s+',paragraph)
        for part in parts:
            part=part.strip()
            if not part:continue
            while len(part)>180:
                cut=max(part.rfind(' ',0,181),part.rfind(',',0,181))
                cut=cut+1 if cut>80 else 180
                units.append({'text':part[:cut].strip(),'kind':'context_uncertain'})
                part=part[cut:].strip()
            kind=reading_kind(part)
            # Keep a greeting with adjacent explanation, but keep actual questions
            # and the busy telephone reply in their own generation context.
            if units and kind=='declarative' and units[-1]['kind']==kind and len(units[-1]['text'])+len(part)<180:
                units[-1]['text']+=' '+part
            else:units.append({'text':part,'kind':kind})
    for unit in units:
        unit.update(preset=preset,targetEnding='light_natural_rise' if unit['kind']=='question' else 'calm_fall_or_neutral',
                    directIntonationControl=False,actualListening=False)
    return units

def ending_review(wave,rate,kind):
    """Measure an ending, never alter F0. Measurements do not prove naturalness."""
    frame=max(1,int(rate*.04));hop=max(1,int(rate*.015));pitches=[]
    for start in range(max(0,len(wave)-int(rate*1.5)),max(0,len(wave)-frame),hop):
        x=np.asarray(wave[start:start+frame],dtype='float64');x=x-x.mean()
        if np.sqrt(np.mean(x*x))<.006:continue
        x=x*np.hanning(len(x));spectrum=np.fft.rfft(x,2048);corr=np.fft.irfft(spectrum*np.conj(spectrum),2048)[:frame]
        if corr[0]<=0:continue
        low,high=max(1,int(rate/450)),min(frame-1,int(rate/75));lag=low+int(np.argmax(corr[low:high]))
        if corr[lag]/corr[0]>.6:pitches.append((start/rate,rate/lag))
    result={'status':'unverified','actualListening':False,'directPitchModification':False,'kind':kind,'violations':[]}
    if len(pitches)<8:return result
    end=pitches[-1][0];values=[p for t,p in pitches if t>end-.65]
    if len(values)<8:return result
    span=max(2,len(values)//3);change=float(12*np.log2(np.median(values[-span:])/np.median(values[:span])))
    result.update(status='measured_not_listened',endingChangeSemitones=round(change,3),voicedFrames=len(values))
    if abs(change)>5:result['violations'].append('exaggerated_ending_contour')
    elif kind in ('declarative','busy_firm') and change>1.5:result['violations'].append('declarative_rises')
    elif kind=='question' and change<.25:result['violations'].append('question_rise_not_confirmed')
    return result

def validate_generated_take(waveform,rate,text):
    """Reject damaged generation; do not trim breaths or change speech timing."""
    if rate<=0 or not len(waveform) or not np.isfinite(waveform).all():
        raise TakeRejected('정상 음성이 생성되지 않았어요.')
    peak=float(np.max(np.abs(waveform)))
    if float(np.sqrt(np.mean(waveform.astype(np.float64)**2))) < .001:
        raise TakeRejected('생성 결과에서 정상적인 말소리가 확인되지 않아 내보내지 않았어요.')
    # Reject severe isolated digital clicks. Do not remove consonants or guess
    # that every short acoustic transient is a microphone collision.
    left=waveform[1:-1]-waveform[:-2];right=waveform[2:]-waveform[1:-1]
    candidates=np.flatnonzero((np.abs(left)>.25)&(np.abs(right)>.25)&(left*right<0))+1
    for index in candidates:
        neighbours=np.r_[waveform[max(0,index-12):max(0,index-1)],waveform[index+2:index+13]]
        if len(neighbours) and abs(float(waveform[index]))>float(np.max(np.abs(neighbours)))*6+.05:
            raise TakeRejected('툭 튀는 충격음이 의심돼 이 음성은 내보내지 않았어요. 다시 만들어 주세요.')
    window=max(1,int(rate*.01));count=len(waveform)//window
    longest=0.
    if count:
        quiet=np.max(np.abs(waveform[:count*window].reshape(-1,window)),axis=1)<min(.01,peak*.02)
        edges=np.diff(np.r_[False,quiet,False].astype('int8'))
        longest=max(((e-s)*window/rate for s,e in zip(np.flatnonzero(edges==1),np.flatnonzero(edges==-1))),default=0.)
    if longest>5 or len(waveform)/rate>len(text)*.6+10:
        raise TakeRejected('생성 중 지나치게 긴 공백이나 꼬리음이 생겨 저장을 멈췄어요. 대본을 짧게 나눠 다시 만들어 주세요.')
    return {'durationSeconds':len(waveform)/rate,'longestQuietSeconds':longest,'audioListening':'unverified'}

def owner_recordings(app_root: Path, voice_dir: Path):
    root=voice_dir.parent
    entries=[(p,voice_dir) for p in json.loads((root/'profiles.json').read_text(encoding='utf-8'))]
    for metadata in sorted((root/'archived-profiles').glob('*/profile.json')):
        entry=json.loads(metadata.read_text(encoding='utf-8'))
        folder=metadata.parent if (metadata.parent/entry.get('audioFile','')).is_file() else voice_dir
        entries.append((entry,folder))
    for metadata in sorted((root/'arang-references').glob('*/profile.json')):
        entries.append((json.loads(metadata.read_text(encoding='utf-8')),metadata.parent))
    seen=set();sources=[]
    for entry,folder in entries:
        if entry.get('ownerName')!='아랑':continue
        name=entry.get('audioFile','')
        if not name or Path(name).name!=name:raise ValueError('Invalid owner reference path')
        path=folder/name
        if not path.is_file() or not entry.get('referenceText','').strip():
            raise RuntimeError('아랑 원본 녹음이나 녹음 대본이 빠져 있어 생성을 멈췄어요.')
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        if digest in seen:continue
        seen.add(digest)
        sources.append({'id':entry['id'],'name':entry['displayName'],'path':str(path.resolve()),
                        'sha256':digest,'text':entry['referenceText']})
    if not sources:raise RuntimeError('아랑 원본 녹음이 없어요.')
    return sources

def synthesize_owner(text,profile,app_root,voice_dir,delivery=None):
    import torch
    sources=owner_recordings(app_root,voice_dir)
    key=tuple((s['id'],s['sha256'],hashlib.sha256(s['text'].encode()).hexdigest()) for s in sources)
    with _lock:
        model=_engine(app_root)
        prompts=_cache.get(key)
        if prompts is None:
            recordings=[]
            for source in sources:
                waveform,rate=sf.read(source['path'],dtype='float32')
                if waveform.ndim>1:waveform=waveform.mean(axis=1)
                recordings.append((waveform,rate))
            prompts=model.create_voice_clone_prompt(ref_audio=recordings,ref_text=[s['text'] for s in sources])
            if len(prompts)!=len(sources):raise RuntimeError('일부 원녹음이 참조에 연결되지 않았어요.')
            _cache.clear();_cache[key]=prompts
        # Keep every original in the bank, but do not invent a new voice by
        # averaging speaker embeddings. Official cloning uses the selected
        # original prompt unchanged. Calm mode uses the normal Arang recording.
        index=next((i for i,s in enumerate(sources) if s['id']==profile['id']),0)
        calm=bool(delivery and delivery.get('preset')=='calm_contextual')
        managed=bool(delivery)
        if calm:index=next((i for i,s in enumerate(sources) if s['name']=='아랑'),index)
        template=prompts[index]
        prompt=template
        budget=min(4096,max(256,len(text)*(8 if managed else 12)))
        attempt=int((delivery or {}).get('attempt',0))
        torch.manual_seed(20261107+sum(map(ord,text))+attempt*9973)
        # Lower sampling temperatures produced long silent tails in real app QA.
        # Use official cloning sampling; calm delivery comes from the unchanged
        # normal recording, not an unsupported assumption about temperature.
        temperature=.9
        waveforms,rate=model.generate_voice_clone(
            text=text,language='Korean',voice_clone_prompt=[prompt],non_streaming_mode=False,
            do_sample=True,temperature=temperature,top_p=1.,top_k=50,repetition_penalty=1.05,
            subtalker_dosample=True,subtalker_temperature=.9,subtalker_top_p=1.,subtalker_top_k=50,max_new_tokens=budget,
        )
        waveform=np.asarray(waveforms[0],dtype=np.float32).reshape(-1)
        review=ending_review(waveform,int(rate),delivery.get('kind','context_uncertain')) if managed else {'status':'unverified','actualListening':False,'violations':[]}
        if managed:
            diagnostic=voice_dir.parent/'reading-diagnostics';diagnostic.mkdir(exist_ok=True)
            take=diagnostic/(uuid.uuid4().hex+'.wav');sf.write(take,waveform,rate,subtype='PCM_16')
            take.with_suffix('.json').write_text(json.dumps({'text':text,'delivery':delivery,'endingReview':review,'temperature':temperature,'actualListening':False},ensure_ascii=False,indent=2),encoding='utf-8')
        try:
            if review['violations']:
                raise TakeRejected('말끝 검사에서 읽기 기준과 맞지 않는 부분이 있어 내보내지 않았어요. 현재 Qwen은 억양을 직접 지정할 수 없어 청취 검수와 재생성 판단이 필요해요.')
            quality=validate_generated_take(waveform,rate,text)
        except RuntimeError as error:
            if managed:
                record=json.loads(take.with_suffix('.json').read_text(encoding='utf-8'))
                record.update(status='rejected',reason=str(error),qualityApproved=False)
                take.with_suffix('.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
            raise
        if len(waveform)/rate >= (budget-8)/12:
            raise TakeRejected('문장이 끝나기 전에 생성 한도에 도달했어요. 잘린 결과는 내보내지 않았습니다.')
        peak=float(np.max(np.abs(waveform)))
        if peak>1:waveform=waveform/peak*.98
        audit={'engine':ENGINE_ID,'modelPath':str(voice_dir.parent/'private-model/models/Qwen3-TTS-12Hz-0.6B-Base'),
               'training':False,'personalCheckpoint':False,'referenceCount':len(sources),
               'referenceBankCount':len(sources),'conditioningReferenceCount':1,'speakerEmbeddingBlended':False,
               'references':[{k:s[k] for k in ('id','name','path','sha256')} for s in sources],
               'prosodyReferenceId':sources[index]['id'],'audioListening':'unverified',
               'generationMode':'official-clone-default-false','signalReview':quality,
               'readingDelivery':delivery,'endingReview':review,'samplingTemperature':temperature,
               'directIntonationControl':False,'actualListening':False,'qualityApproved':False}
        return waveform,int(rate),audit
