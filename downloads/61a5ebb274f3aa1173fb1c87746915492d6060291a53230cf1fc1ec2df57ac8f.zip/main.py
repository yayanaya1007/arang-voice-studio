from __future__ import annotations

import json
import ipaddress
import hashlib
import os
import re
import secrets
import socket
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlencode, urlsplit

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, SecretStr
from starlette.concurrency import run_in_threadpool
from starlette.background import BackgroundTask
from starlette.middleware.sessions import SessionMiddleware
from workspaces import WorkspaceStore, atomic_json


ROOT = Path(__file__).resolve().parent
DATA = Path(os.getenv("ARANG_DATA_DIR", str(ROOT / "data"))).resolve()
VOICE_DIR = DATA / "voices"
OUTPUT_DIR = DATA / "audio"
PREVIEW_DIR = DATA / "previews"
STATIC_DIR = ROOT / "static"
VOICE_PROVIDER = os.getenv("VOICE_PROVIDER", "local").strip().lower()
PROFILE_FILE = DATA / "profiles.json"
ACCESS_CODE_FILE = DATA / "access-code.txt"
SESSION_SECRET_FILE = DATA / "session-secret.txt"
MAX_REFERENCE_BYTES = 25 * 1024 * 1024
ALLOWED_AUDIO_SUFFIXES = {".wav", ".mp3", ".m4a"}
PRIVATE_MODEL_STATUS = "official-qwen3-tts-0.6b-base"
SCENEMAKER_ORIGIN = "https://scene-maker-studio.ohjiye.chatgpt.site"
SCENEMAKER_LOCAL_ORIGIN = "http://127.0.0.1:4317"
SCENEMAKER_ALLOWED_ORIGINS = {SCENEMAKER_ORIGIN, SCENEMAKER_LOCAL_ORIGIN}
ORIGINAL_VOICES = {
    "original:baby-cute": {
        "id": "original:baby-cute",
        "gender": "female",
        "ageGroup": "child",
        "displayName": "아기 · 맑고 귀여운 목소리",
        "ownerName": "오리지널 AI 음성",
        "voiceType": "design",
        "instruction": "A fictional three-year-old toddler girl speaking Korean. A distinctly very young, tiny, high-pitched child voice with a small vocal tract, light breathy resonance and soft little consonants. Sweet, playful, innocent and curious, with small natural pauses and bouncy childlike intonation. Clearly a toddler, not an adult woman, not an announcer. Keep the words understandable, gentle and unhurried. No screaming or exaggerated cartoon squeaks.",
        "pitchTargetHz": 380,
        "previewRevision": 2,
        "previewText": "안녕! 나는 아기야. 오늘은 뭐 하고 놀까? 엄마랑 같이 재미있게 놀고 싶어!",
    },
    "original:conversational": {
        "id": "original:conversational",
        "gender": "female",
        "displayName": "AI 오리지널 · 자연스러운 대화체 (추천)",
        "ownerName": "오리지널 AI 음성",
        "voiceType": "design",
        "instruction": "한국어 성인 여성 내레이션 목소리. 친구 한 명에게 생활 정보를 설명하듯 자연스럽게 대화합니다. 편안한 중음대의 음색과 또렷한 발음을 유지하고, 문장마다 억양을 조금씩 바꾸며 짧고 자연스러운 쉼을 둡니다. 지나치게 매끈한 광고 톤이나 방송 아나운서 톤, 과장된 감정 표현, 특정 인물 모방은 피합니다.",
    },
    "original:warm-clear": {
        "id": "original:warm-clear",
        "gender": "female",
        "displayName": "AI 오리지널 · 따뜻하고 또렷한",
        "ownerName": "오리지널 AI 음성",
        "voiceType": "design",
        "instruction": "한국어 성인 여성 내레이션 목소리. 따뜻하고 또렷하며 편안한 친구처럼 대화하듯 말합니다. 보통 속도로 문장 사이에 자연스러운 짧은 쉼을 두고, 과장된 연기 없이 발음을 명확하게 합니다.",
    },
    "original:calm-low": {
        "id": "original:calm-low",
        "gender": "male",
        "displayName": "남성 · 편안한 중저음",
        "ownerName": "오리지널 AI 음성",
        "voiceType": "custom",
        "speaker": "Dylan",
        "instruction": "한국어 성인 남성 내레이션 목소리. 중저음의 따뜻하고 안정적인 음색으로, 친한 사람에게 설명하듯 편안하고 자연스럽게 말합니다. 너무 느리지 않은 속도와 또렷한 발음, 문장마다 살짝 달라지는 억양, 짧은 자연스러운 쉼을 사용합니다. 권위적인 방송 톤이나 과장된 연기는 피하고 특정 인물을 따라 하지 않는 독립적인 목소리로 표현합니다.",
    },
    "original:male-lively": {
        "id": "original:male-lively",
        "gender": "male",
        "displayName": "남성 · 또렷한 광고 내레이션",
        "ownerName": "오리지널 AI 음성",
        "voiceType": "custom",
        "speaker": "Ryan",
        "instruction": "한국어 성인 남성의 분명한 중간 음역 목소리. 가볍게 밝고 자신감 있는 광고 내레이션 분위기로, 또렷한 자음과 자연스러운 리듬을 사용합니다. 음역을 여성처럼 높거나 가늘게 만들지 말고 남성의 단단하고 편안한 울림을 유지합니다. 빠르게 몰아치거나 과장하지 말고, 중요한 단어만 살짝 강조합니다. 특정 성우를 모방하지 않는 독립적인 목소리로 표현합니다.",
    },
    "original:bright-friendly": {
        "id": "original:bright-friendly",
        "gender": "female",
        "displayName": "AI 오리지널 · 밝고 친근한",
        "ownerName": "오리지널 AI 음성",
        "voiceType": "design",
        "instruction": "한국어 성인 여성 목소리. 밝고 호기심이 느껴지는 친근한 대화체로 말합니다. 편안한 중간 속도와 분명한 발음을 유지하고, 지나치게 높은 톤이나 들뜬 광고식 억양은 사용하지 않습니다.",
    },
    "original:gentle-friendly": {
        "id": "original:gentle-friendly",
        "gender": "male",
        "displayName": "남성 · 정겨운 예능 아저씨톤",
        "ownerName": "오리지널 AI 음성",
        "voiceType": "custom",
        "speaker": "Uncle_Fu",
        "instruction": "따뜻하고 정겨운 중년 남성 예능 내레이션. 편하게 이야기하듯 말하고 짧게 쉰다. 특정 방송인이나 성우는 모방하지 않는다.",
    },
}

for folder in (DATA, VOICE_DIR, OUTPUT_DIR, PREVIEW_DIR):
    folder.mkdir(parents=True, exist_ok=True)


def get_access_code() -> str:
    configured = os.getenv("VOICE_STUDIO_ACCESS_CODE", "").strip()
    if configured:
        return configured
    if ACCESS_CODE_FILE.exists():
        return ACCESS_CODE_FILE.read_text(encoding="utf-8").strip()
    code = secrets.token_urlsafe(6)
    ACCESS_CODE_FILE.write_text(code, encoding="utf-8")
    return code


ACCESS_CODE = get_access_code()


def get_session_secret() -> str:
    configured = os.getenv("VOICE_STUDIO_SESSION_SECRET", "").strip()
    if configured:
        return configured
    if SESSION_SECRET_FILE.exists():
        saved = SESSION_SECRET_FILE.read_text(encoding="utf-8").strip()
        if saved:
            return saved
    secret = secrets.token_urlsafe(32)
    SESSION_SECRET_FILE.write_text(secret, encoding="utf-8")
    return secret


SESSION_SECRET = get_session_secret()
workspace_store = WorkspaceStore(DATA / "workspaces", SESSION_SECRET, ACCESS_CODE)
app = FastAPI(title="Arang Local Voice Studio")
app.add_middleware(SessionMiddleware, secret_key=SESSION_SECRET, same_site="lax", https_only=False, max_age=365 * 24 * 60 * 60)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# The local server can also sit behind a localhost-only HTTPS tunnel. Limit
# password guessing before exposing its login form through that tunnel.
_login_failures: dict[str, list[float]] = {}
_login_lock = threading.Lock()
_login_window_seconds = 15 * 60
_login_failure_limit = 5


def _login_client_key(request: Request) -> str:
    peer = request.client.host if request.client else "unknown"
    if peer in {"127.0.0.1", "::1"}:
        forwarded = request.headers.get("cf-connecting-ip", "").strip()
        if forwarded and len(forwarded) <= 45:
            return forwarded
    return peer


def _login_failure_count(key: str, *, failed: bool = False) -> int:
    now = time.monotonic()
    with _login_lock:
        recent = [at for at in _login_failures.get(key, []) if now - at < _login_window_seconds]
        if failed:
            recent.append(now)
        if recent:
            _login_failures[key] = recent
        else:
            _login_failures.pop(key, None)
        return len(recent)


@app.middleware("http")
async def scene_maker_bridge(request: Request, call_next: Any) -> Response:
    if not request.url.path.startswith("/api/bridge/"):
        origin = request.headers.get("origin", "")
        if request.method not in {"GET", "HEAD", "OPTIONS"} and origin and origin.rstrip("/") != str(request.base_url).rstrip("/"):
            return JSONResponse({"detail": "이 사이트에서 직접 요청해 주세요."}, status_code=403)
        response = await call_next(request)
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response
    if request.client is None or request.client.host not in {"127.0.0.1", "::1"}:
        return JSONResponse({"detail": "이 PC에서만 연결할 수 있어요."}, status_code=403)
    origin = request.headers.get("origin")
    if origin and origin not in SCENEMAKER_ALLOWED_ORIGINS:
        return JSONResponse({"detail": "허용되지 않은 사이트예요."}, status_code=403)
    if request.method == "OPTIONS":
        response: Response = Response(status_code=204)
    else:
        response = await call_next(request)
    if origin in SCENEMAKER_ALLOWED_ORIGINS:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type, X-Voice-Studio-Code"
        response.headers["Access-Control-Allow-Private-Network"] = "true"
        response.headers["Access-Control-Max-Age"] = "600"
        response.headers["Vary"] = "Origin"
    return response

_model: Any | None = None
_loaded_model_name: str | None = None
_model_lock = threading.Lock()
_inference_lock = threading.Lock()
_preview_lock = threading.Lock()
PREVIEW_SCRIPT = "안녕하세요. 오늘은 인공지능을 어렵지 않게 활용하는 방법을 함께 알아볼게요. 궁금한 것부터 하나씩 천천히 시작해봐요."


def read_profiles() -> list[dict[str, Any]]:
    if not PROFILE_FILE.exists():
        return []
    try:
        data = json.loads(PROFILE_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, list) or any(not isinstance(item, dict) for item in data):
            raise ValueError("Invalid profile registry")
        return data
    except (OSError, ValueError) as exc:
        raise HTTPException(status_code=503, detail="저장된 목소리 목록을 읽지 못했어요. 원본 보호를 위해 저장과 삭제를 멈췄습니다.") from exc


def write_profiles(profiles: list[dict[str, Any]]) -> None:
    replacements = {profile.get("id"): profile for profile in profiles}
    for saved in read_profiles():
        if saved.get("protected") and replacements.get(saved.get("id")) != saved:
            raise ValueError("보호된 목소리 프로필은 삭제하거나 덮어쓸 수 없어요.")
    temporary = PROFILE_FILE.with_suffix(".tmp")
    temporary.write_text(json.dumps(profiles, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(PROFILE_FILE)


def get_voice(profile_id: str) -> dict[str, Any] | None:
    original_voice = ORIGINAL_VOICES.get(profile_id)
    if original_voice:
        return original_voice
    return next((profile for profile in read_profiles() if profile.get("id") == profile_id), None)


def voice_choices() -> list[dict[str, str]]:
    saved = [
        {
            "id": str(profile["id"]),
            "displayName": str(profile["displayName"]),
            "ownerName": str(profile.get("ownerName", "목소리 프로필")),
            "voiceType": "clone",
        }
        for profile in read_profiles()
    ]
    designed = [
        {**{key: str(voice[key]) for key in ("id", "displayName", "ownerName", "voiceType", "gender")}, "ageGroup": str(voice.get("ageGroup", "adult"))}
        for voice in ORIGINAL_VOICES.values()
    ]
    return saved + designed


def require_login(request: Request) -> str:
    if request.session.get("signed_in") is not True:
        raise HTTPException(status_code=401, detail="로그인이 필요해요.")
    identity = request.session.setdefault("workspace_id", "owner")
    expected = request.headers.get("x-arang-workspace", "")
    if expected and expected != identity:
        raise HTTPException(status_code=409, detail="다른 작업실로 로그인됐어요. 새로고침 후 다시 작업해 주세요.")
    try:
        workspace_store.account(identity)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail="로그인이 필요해요.") from exc
    return identity


@app.get("/api/scene-maker-link")
async def scene_maker_link(request: Request) -> dict[str, str]:
    identity = require_login(request)
    target = SCENEMAKER_ORIGIN
    try:
        with socket.create_connection(("127.0.0.1", 4317), timeout=0.25):
            target = SCENEMAKER_LOCAL_ORIGIN
    except OSError:
        pass
    return_url = voice_studio_return_url(request)
    handoff = urlencode({"arang": workspace_store.bridge_token(identity), "arangReturn": return_url})
    return {"url": f"{target}/#{handoff}"}


def voice_studio_return_url(request: Request) -> str:
    candidates = [request.headers.get("referer", "")]
    try:
        candidates.append((DATA / "current-web-url.txt").read_text(encoding="utf-8").strip())
    except OSError:
        pass
    candidates.append("http://127.0.0.1:8787/")

    for candidate in candidates:
        try:
            parsed = urlsplit(candidate)
            hostname = parsed.hostname or ""
            if parsed.username or parsed.password:
                continue
            if parsed.scheme == "https" and hostname.endswith(".trycloudflare.com"):
                return f"https://{parsed.netloc}/"
            if parsed.scheme == "http" and parsed.port == 8787:
                if hostname in {"127.0.0.1", "localhost"}:
                    return f"http://{parsed.netloc}/"
                try:
                    if ipaddress.ip_address(hostname).is_private:
                        return f"http://{parsed.netloc}/"
                except ValueError:
                    pass
        except ValueError:
            continue
    return "http://127.0.0.1:8787/"


def require_scene_maker_code(request: Request) -> str:
    supplied = request.headers.get("x-voice-studio-code", "")
    identity = workspace_store.bridge_identity(supplied) if supplied else None
    if not identity:
        raise HTTPException(status_code=401, detail="아랑 앱의 접속 코드를 확인해 주세요.")
    return identity


@app.get("/api/bridge/status")
async def bridge_status() -> dict[str, bool]:
    return {"running": True}


@app.get("/api/bridge/profiles")
async def bridge_profiles(request: Request) -> list[dict[str, str]]:
    require_scene_maker_code(request)
    return [{"id": voice["id"], "displayName": voice["displayName"]} for voice in voice_choices()]


@app.get("/", response_class=HTMLResponse)
async def home() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-store"})


@app.get("/api/status")
async def status(request: Request) -> dict[str, Any]:
    account = workspace_store.account(require_login(request)) if request.session.get("signed_in") else None
    if account:
        # SessionMiddleware renews a persistent cookie only for modified sessions.
        # The signed-in heartbeat keeps this browser's own workspace remembered.
        request.session["workspace_id"] = account["id"]
    return {
        "signedIn": request.session.get("signed_in") is True,
        "modelLoaded": _model is not None,
        "model": PRIVATE_MODEL_STATUS,
        "localStorage": True,
        "workspace": account,
        "needsPasswordSetup": not (workspace_store.root / "accounts.json").exists() and _login_client_key(request) in {"127.0.0.1", "::1", "testclient"},
    }


@app.get("/desktop-updates/{channel}/{filename}")
async def desktop_update(channel: str, filename: str) -> FileResponse:
    channel_file = DATA / "desktop-update-channel.txt"
    if not channel_file.exists() or not secrets.compare_digest(channel, channel_file.read_text(encoding="utf-8").strip()):
        raise HTTPException(status_code=404, detail="업데이트를 찾지 못했어요.")
    if filename not in {"latest.json", "ArangVoiceStudio-Notebook.zip", "ArangVoiceStudio-Setup.exe"} and not re.fullmatch(r"[a-f0-9]{64}\.zip", filename):
        raise HTTPException(status_code=404, detail="업데이트를 찾지 못했어요.")
    path = DATA / "desktop-publish" / filename
    if not path.is_file():
        raise HTTPException(status_code=404, detail="업데이트를 찾지 못했어요.")
    return FileResponse(path, headers={"Cache-Control": "no-store"})


@app.get("/api/desktop-installer")
async def desktop_installer(request: Request) -> Response:
    require_login(request)
    install_root = os.getenv("ARANG_DESKTOP_INSTALL_ROOT", "")
    if install_root:
        folder = Path(install_root)
        settings = json.loads((folder / "desktop-settings.json").read_text(encoding="utf-8-sig"))
        if settings.get("installerUrl"):
            link = urlsplit(settings["installerUrl"])
            if link.scheme != "https" or not link.hostname or link.username or link.password:
                raise HTTPException(status_code=503, detail="업데이트 연결 주소를 확인해 주세요.")
            return RedirectResponse(settings["installerUrl"], status_code=307, headers={"Cache-Control":"no-store"})
        source_file = folder / "update-source.txt"
        source = (source_file.read_text(encoding="utf-8-sig").strip() if source_file.exists() else settings["source"]).rstrip("/")
        parsed = urlsplit(source)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
            raise HTTPException(status_code=503, detail="업데이트 연결 주소를 확인해 주세요.")
        return RedirectResponse(source + "/desktop-updates/" + settings["channel"] + "/ArangVoiceStudio-Notebook.zip", status_code=307, headers={"Cache-Control":"no-store"})
    path = DATA / "desktop-public" / "ArangVoiceStudio-Notebook.zip"
    if not path.is_file():
        path = DATA / "desktop-publish" / "ArangVoiceStudio-Notebook.zip"
    if not path.is_file():
        raise HTTPException(status_code=404, detail="설치 파일을 준비 중입니다.")
    return FileResponse(path, media_type="application/zip", filename=path.name, headers={"Cache-Control":"no-store"})


class LoginRequest(BaseModel):
    accessCode: str


class PasswordRequest(BaseModel):
    password: SecretStr
    confirmation: SecretStr


def chosen_password(payload: PasswordRequest) -> str:
    value = payload.password.get_secret_value()
    if value != payload.confirmation.get_secret_value():
        raise HTTPException(status_code=400, detail="두 비밀번호가 서로 달라요.")
    if not 8 <= len(value) <= 128:
        raise HTTPException(status_code=400, detail="비밀번호는 8자 이상 128자 이하로 정해 주세요.")
    return value


@app.post("/api/setup")
async def first_password(payload: PasswordRequest, request: Request) -> dict[str, bool]:
    if _login_client_key(request) not in {"127.0.0.1", "::1", "testclient"}:
        raise HTTPException(status_code=403, detail="처음 비밀번호는 설치한 컴퓨터에서 정해 주세요.")
    with workspace_store.lock:
        if (workspace_store.root / "accounts.json").exists():
            raise HTTPException(status_code=409, detail="이미 시작한 작업실이에요. 기존 비밀번호로 접속해 주세요.")
        workspace_store.set_password("owner", chosen_password(payload))
    request.session.clear()
    request.session.update({"signed_in": True, "workspace_id": "owner"})
    return {"ok": True}


@app.post("/api/workspace/password")
async def save_my_password(payload: PasswordRequest, request: Request) -> dict[str, bool]:
    identity = require_login(request)
    workspace_store.set_password(identity, chosen_password(payload))
    return {"ok": True}


@app.post("/api/login")
async def login(payload: LoginRequest, request: Request) -> JSONResponse:
    client_key = _login_client_key(request)
    if _login_failure_count(client_key) >= _login_failure_limit:
        raise HTTPException(status_code=429, detail="접속 시도가 많습니다. 15분 후 다시 시도해 주세요.")
    identity = workspace_store.authenticate(payload.accessCode)
    if identity is None:
        _login_failure_count(client_key, failed=True)
        raise HTTPException(status_code=401, detail="접속 코드가 맞지 않아요.")
    with _login_lock:
        _login_failures.pop(client_key, None)
    request.session.clear()
    request.session.update({"signed_in": True, "workspace_id": identity})
    return JSONResponse({"ok": True})


@app.post("/api/logout")
async def logout(request: Request) -> dict[str, bool]:
    request.session.clear()
    return {"ok": True}


@app.post("/api/workspace/invite")
async def create_workspace_invite(request: Request) -> dict[str, str]:
    if workspace_store.account(require_login(request))["role"] != "owner":
        raise HTTPException(status_code=403, detail="초대 링크는 주 작업실에서 만들 수 있어요.")
    token = workspace_store.invite()
    return {"url": str(request.base_url)+"?invite="+token}


@app.get("/api/workspace/invite")
async def inspect_workspace_invite(token: str) -> dict[str, bool]:
    return {"valid": workspace_store.invite_valid(token)}


class JoinWorkspaceRequest(BaseModel):
    token: str
    name: str


@app.get("/api/workspace/members")
async def list_workspace_members(request: Request) -> dict[str, Any]:
    if workspace_store.account(require_login(request))["role"] != "owner":
        raise HTTPException(status_code=403, detail="가족 접속 복구는 주 작업실에서 할 수 있어요.")
    return {"members": workspace_store.members()}


class RecoveryTargetRequest(BaseModel):
    workspaceId: str


@app.post("/api/workspace/recovery-link")
async def create_workspace_recovery(payload: RecoveryTargetRequest, request: Request) -> dict[str, str]:
    if workspace_store.account(require_login(request))["role"] != "owner":
        raise HTTPException(status_code=403, detail="가족 접속 복구는 주 작업실에서 할 수 있어요.")
    try:
        account = workspace_store.account(payload.workspaceId)
        if account["role"] != "member":
            raise ValueError("복구할 가족 작업실을 선택해 주세요.")
        token = workspace_store.recovery_link(account["id"])
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"url": str(request.base_url)+"#recover="+token, "workspaceName": account["name"]}


class RecoveryTokenRequest(BaseModel):
    token: str


@app.post("/api/workspace/recovery-info")
async def inspect_workspace_recovery(payload: RecoveryTokenRequest) -> dict[str, Any]:
    account = workspace_store.recovery_account(payload.token)
    return {"valid": account is not None, "workspaceName": account["name"] if account else ""}


@app.post("/api/workspace/recover")
async def recover_workspace(payload: RecoveryTokenRequest, request: Request) -> dict[str, Any]:
    client = _login_client_key(request)
    if not workspace_store.recovery_account(payload.token):
        if _login_failure_count(client) >= _login_failure_limit:
            raise HTTPException(status_code=429, detail="접속 시도가 많습니다. 15분 후 다시 시도해 주세요.")
        _login_failure_count(client, failed=True)
        raise HTTPException(status_code=400, detail="이미 사용했거나 만료된 복구 링크예요.")
    try:
        identity, code = workspace_store.recover(payload.token)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    with _login_lock:
        _login_failures.pop(client, None)
    request.session.clear()
    request.session.update({"signed_in": True, "workspace_id": identity})
    return {"workspace": workspace_store.account(identity), "accessCode": code}


@app.post("/api/workspace/access-code")
async def reissue_my_access_code(request: Request) -> dict[str, str]:
    return {"accessCode": workspace_store.reset_code(require_login(request))}


@app.post("/api/workspace/join")
async def join_workspace(payload: JoinWorkspaceRequest, request: Request) -> dict[str, Any]:
    client = _login_client_key(request)
    if _login_failure_count(client) >= _login_failure_limit:
        raise HTTPException(status_code=429, detail="접속 시도가 많습니다. 15분 후 다시 시도해 주세요.")
    try:
        identity, code = workspace_store.join(payload.token, payload.name)
    except ValueError as exc:
        _login_failure_count(client, failed=True)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    request.session.clear()
    request.session.update({"signed_in": True, "workspace_id": identity})
    return {"workspace": workspace_store.account(identity), "accessCode": code}


@app.get("/api/workspace/draft")
async def get_workspace_draft(request: Request) -> dict[str, Any]:
    return workspace_store.draft(require_login(request))


class DraftRequest(BaseModel):
    text: str = ""
    profileId: str = ""
    engine: str = "local"
    apiVoiceId: str = ""


@app.put("/api/workspace/draft")
async def save_workspace_draft(payload: DraftRequest, request: Request) -> dict[str, bool]:
    if len(payload.text) > 4000:
        raise HTTPException(status_code=400, detail="대본은 4,000자 이하로 저장해 주세요.")
    workspace_store.save_draft(require_login(request), payload.model_dump())
    return {"ok": True}


def workspace_audio(identity: str) -> Path:
    path = workspace_store.folder(identity)/"audio"
    path.mkdir(exist_ok=True)
    return path


def remember_render(identity: str, path: Path, text: str, voice: str, engine: str) -> None:
    with workspace_store.lock:
        registry = workspace_store.folder(identity)/"history.json"
        data = json.loads(registry.read_text(encoding="utf-8")) if registry.exists() else {"items": []}
        data["items"].insert(0, {"file": path.name, "text": text, "voice": voice, "engine": engine,
                               "createdAt": datetime.now(timezone.utc).isoformat(),
                               "audioUrl": f"/api/audio/{path.name}"})
        data["items"] = data["items"][:100]
        atomic_json(registry, data)


@app.get("/api/workspace/history")
async def get_workspace_history(request: Request) -> dict[str, Any]:
    identity = require_login(request)
    path = workspace_store.folder(identity)/"history.json"
    with workspace_store.lock:
        data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"items": []}
        for item in data["items"]:
            name = item.get("file", "")
            if Path(name).name != name:
                continue
            quality = workspace_audio(identity) / Path(name).with_suffix(".quality.json")
            if quality.is_file():
                review = json.loads(quality.read_text(encoding="utf-8"))
                item["reviewStatus"] = review.get("status", "unverified")
                item["reviewReason"] = review.get("reason", "")
        return data


class ReadingSettingsRequest(BaseModel):
    preset: str = "calm_contextual"


@app.get("/api/workspace/reading-settings")
async def get_reading_settings(request: Request) -> dict[str, Any]:
    return workspace_store.reading_settings(require_login(request))


@app.post("/api/workspace/reading-settings")
async def save_reading_settings(payload: ReadingSettingsRequest, request: Request) -> dict[str, Any]:
    identity=require_login(request)
    try:workspace_store.save_reading_settings(identity,payload.preset)
    except ValueError as error:raise HTTPException(status_code=400,detail=str(error)) from error
    return workspace_store.reading_settings(identity)


class APISettingsRequest(BaseModel):
    provider: str
    apiKey: SecretStr = SecretStr("")
    model: str = ""


@app.get("/api/workspace/api-settings")
async def get_api_settings(request: Request) -> dict[str, Any]:
    settings = workspace_store.settings(require_login(request))
    return {"provider": settings.get("provider", ""), "model": settings.get("model", ""),
            "configured": bool(settings.get("key"))}


@app.put("/api/workspace/api-settings")
async def save_api_settings(payload: APISettingsRequest, request: Request) -> dict[str, bool]:
    identity = require_login(request)
    if payload.provider not in {"openai", "gemini", "elevenlabs"}:
        raise HTTPException(status_code=400, detail="지원하는 API 서비스를 선택해 주세요.")
    previous = workspace_store.settings(identity)
    key = payload.apiKey.get_secret_value().strip()
    if not key and previous.get("provider") == payload.provider:
        key = previous.get("key", "")
    if not key or len(key) > 4096 or any(ch.isspace() for ch in key):
        raise HTTPException(status_code=400, detail="이 작업실에서 사용할 API 키를 입력해 주세요.")
    if payload.model and not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", payload.model):
        raise HTTPException(status_code=400, detail="모델 이름을 확인해 주세요.")
    workspace_store.save_settings(identity, {"provider": payload.provider, "key": key, "model": payload.model})
    return {"ok": True}


@app.delete("/api/workspace/api-settings")
async def clear_api_settings(request: Request) -> dict[str, bool]:
    workspace_store.clear_settings(require_login(request))
    return {"ok": True}


@app.post("/api/workspace/api-check")
async def check_api_settings(request: Request) -> dict[str, Any]:
    from personal_api import available_voices
    settings = workspace_store.settings(require_login(request))
    if not settings.get("key"):
        raise HTTPException(status_code=400, detail="내 작업실에 API를 먼저 연결해 주세요.")
    try:
        voices = await available_voices(settings)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"ok": True, "voices": voices}


@app.get("/api/profiles")
async def list_profiles(request: Request) -> list[dict[str, Any]]:
    require_login(request)
    return [
        {key: value for key, value in profile.items() if key != "audioFile"}
        for profile in read_profiles()
    ]


@app.get("/api/voices")
async def list_voices(request: Request) -> list[dict[str, str]]:
    require_login(request)
    return voice_choices()


@app.post("/api/profiles")
async def create_profile(
    request: Request,
    display_name: str = Form(...),
    owner_name: str = Form(...),
    reference_text: str = Form(...),
    owner_consent: str = Form(...),
    audio: UploadFile = File(...),
) -> dict[str, Any]:
    require_login(request)
    display_name = display_name.strip()
    owner_name = owner_name.strip()
    reference_text = reference_text.strip()
    if owner_consent != "yes":
        raise HTTPException(status_code=400, detail="목소리 주인의 동의를 확인해 주세요.")
    if not display_name or not owner_name or not reference_text:
        raise HTTPException(status_code=400, detail="이름과 녹음 대본을 모두 입력해 주세요.")
    suffix = Path(audio.filename or "").suffix.lower()
    if suffix not in ALLOWED_AUDIO_SUFFIXES:
        raise HTTPException(status_code=400, detail="WAV, MP3, M4A 파일만 사용할 수 있어요.")
    content = await audio.read(MAX_REFERENCE_BYTES + 1)
    if not content or len(content) > MAX_REFERENCE_BYTES:
        raise HTTPException(status_code=400, detail="녹음 파일은 25MB 이하로 올려 주세요.")
    profile_id = uuid.uuid4().hex
    audio_name = f"{profile_id}{suffix}"
    pending_audio = VOICE_DIR / f".upload-{profile_id}{suffix}"
    try:
        pending_audio.write_bytes(content)
        from audio_cleanup import read_audio
        await run_in_threadpool(read_audio, pending_audio)
        pending_audio.replace(VOICE_DIR / audio_name)
    except (OSError, RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail="녹음을 읽지 못했어요. 재생 가능한 WAV, MP3, M4A 파일인지 확인해 주세요.") from exc
    finally:
        pending_audio.unlink(missing_ok=True)
    profile = {
        "id": profile_id,
        "displayName": display_name,
        "ownerName": owner_name,
        "voiceType": "clone",
        "referenceText": reference_text,
        "protected": True,
        "audioFile": audio_name,
        "createdAt": datetime.now(timezone.utc).isoformat(),
    }
    profiles = read_profiles()
    profiles.append(profile)
    write_profiles(profiles)
    return {key: value for key, value in profile.items() if key != "audioFile"}


@app.delete("/api/profiles/{profile_id}")
async def delete_profile(profile_id: str, request: Request) -> dict[str, bool]:
    require_login(request)
    profiles = read_profiles()
    matching = next((item for item in profiles if item.get("id") == profile_id), None)
    if matching is None:
        raise HTTPException(status_code=404, detail="음성 프로필을 찾을 수 없어요.")
    if matching.get("protected"):
        raise HTTPException(status_code=403, detail="영구 보관 중인 목소리예요. 프로필과 원본 녹음은 삭제할 수 없어요.")
    audio_name = matching.get("audioFile", "")
    if audio_name and Path(audio_name).name == audio_name:
        (VOICE_DIR / audio_name).unlink(missing_ok=True)
    for cached_preview in PREVIEW_DIR.glob(f"{profile_id}_*.wav"):
        cached_preview.unlink(missing_ok=True)
    write_profiles([item for item in profiles if item.get("id") != profile_id])
    return {"ok": True}


class SynthesizeRequest(BaseModel):
    profileId: str
    text: str
    preview: bool = False
    engine: str = "local"
    apiVoiceId: str = ""


def speech_chunks(script: str, limit: int = 66) -> list[str]:
    """Keep short adjacent sentences together so speaker context stays usable."""
    chunks: list[str] = []
    for paragraph in re.split(r"\n\s*\n", script.strip()):
        pieces: list[str] = []
        for sentence in re.split(r"(?<=[.!?。！？])\s+", paragraph.strip()):
            sentence = " ".join(sentence.split())
            while len(sentence) > limit:
                cut = max(sentence.rfind(mark, 0, limit + 1) for mark in (",", "，", " "))
                cut = limit if cut < limit // 2 else cut + 1
                pieces.append(sentence[:cut].strip())
                sentence = sentence[cut:].strip()
            if sentence:
                pieces.append(sentence)
        merged: list[str] = []
        for piece in pieces:
            # Keep adjacent sentences in one voice take when they fit. Splitting
            # every sentence produced an audible stop and tone reset at endings.
            if merged and len(merged[-1]) + len(piece) + 1 <= limit:
                merged[-1] += " " + piece
            else:
                merged.append(piece)
        chunks.extend(merged)
    return chunks or [script.strip()]


def synthesize(profile: dict[str, Any], text: str, output_dir: Path | None = None, reading: dict | None = None) -> Path:
    global _model, _loaded_model_name
    import soundfile as sf
    import numpy as np
    from profile_voice_engine import synthesize_saved_profile
    from arang_reference_engine import synthesize_owner, reading_plan, TakeRejected

    is_arang = profile.get("ownerName") == "아랑"
    if not profile.get("audioFile"):
        raise RuntimeError("현재는 원본 녹음이 등록된 목소리만 Qwen으로 만들 수 있어요.")

    pieces = []
    sample_rate = 0
    engine_id = ""
    reference_audit = None
    take_boundaries = []
    sample_cursor = 0
    preset=(reading or {}).get("preset","calm_contextual")
    plan=reading_plan(text,preset) if is_arang else [{"text":c} for c in speech_chunks(text,limit=280)]
    for delivery in plan:
        chunk=delivery["text"]
        if is_arang:
            for attempt in range(2):
                try:
                    take_delivery={**delivery,"preset":preset,"attempt":attempt}
                    wave, rate, reference_audit = synthesize_owner(chunk, profile, ROOT, VOICE_DIR,take_delivery)
                    break
                except TakeRejected:
                    if attempt:raise
            engine_id = reference_audit["engine"]
        else:
            wave, rate, engine_id = synthesize_saved_profile(chunk, profile, ROOT, VOICE_DIR)
        if sample_rate and sample_rate != rate:
            raise RuntimeError("나눠 만든 음성 파일의 형식이 서로 맞지 않아요.")
        sample_rate = rate
        if pieces:
            pieces.append(np.zeros(int(sample_rate * 0.16), dtype=np.float32))
            sample_cursor += len(pieces[-1])
        take_boundaries.append({"textSha256": hashlib.sha256(chunk.encode()).hexdigest(),
                                "startSeconds": sample_cursor / sample_rate,
                                "endSeconds": (sample_cursor + len(wave)) / sample_rate,
                                "readingDelivery":delivery,"endingReview":reference_audit.get("endingReview") if reference_audit else None})
        pieces.append(wave)
        sample_cursor += len(wave)

    if not pieces or sample_rate <= 0:
        raise RuntimeError("합성할 문장이 없어요.")
    _loaded_model_name = engine_id
    waveform = np.concatenate(pieces + [np.zeros(int(sample_rate * 0.25), dtype=np.float32)])
    destination = output_dir or OUTPUT_DIR
    destination.mkdir(parents=True, exist_ok=True)
    output_path = destination / f"{uuid.uuid4().hex}.wav"
    sf.write(output_path, waveform, sample_rate, subtype="PCM_16")
    output_path.with_suffix(".json").write_text(
        json.dumps({"sampleRate": sample_rate, "engine": engine_id, "parts": len(take_boundaries),
                    "takes": take_boundaries, "joinGapSeconds": 0.16, "finalPaddingSeconds": 0.25,
                    "referenceAudit": reference_audit,"readingSettings":reading or {"preset":preset},
                    "actualListening":False,"qualityApproved":False}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return output_path


def synthesize_with_provider(profile: dict[str, Any], text: str, output_dir: Path | None = None, reading: dict | None = None) -> Path:
    if VOICE_PROVIDER == "local":
        generated = synthesize(profile, text, output_dir, reading)
        if profile.get("voiceType", "clone") == "clone":
            from audio_cleanup import cleaned_copy
            cleaned, report = cleaned_copy(generated, output_dir or OUTPUT_DIR)
            from arang_reference_engine import validate_generated_take
            import soundfile as sf
            checked_wave, checked_rate = sf.read(cleaned, dtype="float32")
            signal_review = validate_generated_take(checked_wave, checked_rate, text)
            metadata = generated.with_suffix(".json")
            if metadata.is_file():
                details = json.loads(metadata.read_text(encoding="utf-8"))
                details["noiseCleanup"] = report
                details["signalReview"] = signal_review
                details["actualListening"] = False
                cleaned.with_suffix(".json").write_text(json.dumps(details, ensure_ascii=False, indent=2), encoding="utf-8")
            return cleaned
        return generated
    if VOICE_PROVIDER == "typecast":
        raise RuntimeError("Typecast 연결을 켜기 전에 공식 API 이용 조건과 API 키 설정이 필요해요. 현재는 로컬 음성만 사용할 수 있어요.")
    raise RuntimeError(f"지원하지 않는 음성 제공 방식이에요: {VOICE_PROVIDER}")


def get_or_create_preview(profile: dict[str, Any]) -> Path:
    cache_path = preview_cache_path(profile)
    with _preview_lock:
        # Keep the first approved clone sample stable. New sampling settings can
        # make a later preview sound like a different speaker even with the same
        # unchanged reference recording.
        safe_id = str(profile.get("id", "voice")).replace(":", "_")
        if profile.get("voiceType", "clone") == "clone":
            approved = sorted(PREVIEW_DIR.glob(f"{safe_id}_*.wav"),
                              key=lambda item: item.stat().st_mtime)
            for sample in approved:
                if sample.stat().st_size > 44:
                    return sample
        if cache_path.is_file() and cache_path.stat().st_size > 44:
            return cache_path
        # A profile ID is immutable. Reuse its saved sample when a cache-version
        # change alters the digest. Revisioned presets intentionally rebuild.
        previous = [] if profile.get("previewRevision") else sorted(PREVIEW_DIR.glob(f"{safe_id}_*.wav"),
                          key=lambda item: item.stat().st_mtime, reverse=True)
        for sample in previous:
            if sample.stat().st_size > 44:
                return sample
        generated_path = synthesize_with_provider(profile, profile.get("previewText", PREVIEW_SCRIPT))
        generated_path.replace(cache_path)
        generated_path.with_suffix(".json").unlink(missing_ok=True)
    return cache_path


@app.get("/api/preview/{profile_id}")
async def get_voice_preview(profile_id: str, request: Request) -> FileResponse:
    require_login(request)
    profile = get_voice(profile_id)
    if profile is None:
        raise HTTPException(status_code=404, detail="음성 프로필을 찾을 수 없어요.")
    if profile.get("voiceType", "clone") == "clone":
        audio_name = profile.get("audioFile", "")
        if audio_name and Path(audio_name).name == audio_name:
            original = VOICE_DIR / audio_name
            if original.is_file():
                from audio_cleanup import cleaned_copy
                cleaned, report = await run_in_threadpool(cleaned_copy, original, DATA / "clean-voices")
                return FileResponse(cleaned, media_type="audio/wav", headers={
                    "Cache-Control": "no-store", "X-Arang-Cleanup": "applied" if report.get("applied") else "skipped"})
        raise HTTPException(status_code=404, detail="원본 녹음을 찾지 못했어요.")
    try:
        preview_path = await run_in_threadpool(get_or_create_preview, profile)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return FileResponse(preview_path, media_type="audio/wav", headers={"Cache-Control": "no-store"})


@app.get("/api/reference/{profile_id}")
async def get_original_recording(profile_id: str, request: Request) -> FileResponse:
    require_login(request)
    profile = next((item for item in read_profiles() if item.get("id") == profile_id), None)
    if profile is None:
        raise HTTPException(status_code=404, detail="원본 녹음이 없는 목소리예요.")
    audio_name = profile.get("audioFile", "")
    if not audio_name or Path(audio_name).name != audio_name:
        raise HTTPException(status_code=404, detail="원본 녹음을 찾지 못했어요.")
    audio_path = VOICE_DIR / audio_name
    if not audio_path.is_file():
        raise HTTPException(status_code=404, detail="원본 녹음을 찾지 못했어요.")
    return FileResponse(audio_path, headers={"Cache-Control": "no-store"})


@app.get("/api/profiles/{profile_id}/quality")
async def profile_quality(profile_id: str, request: Request) -> dict[str, Any]:
    require_login(request)
    profile = next((item for item in read_profiles() if item.get("id") == profile_id), None)
    name = profile.get("audioFile", "") if profile else ""
    if not name or Path(name).name != name or not (VOICE_DIR / name).is_file():
        raise HTTPException(status_code=404, detail="분석할 원본 녹음을 찾지 못했어요.")
    from audio_cleanup import recording_quality
    try:
        return await run_in_threadpool(recording_quality, VOICE_DIR / name, DATA / "clean-voices")
    except (RuntimeError, ValueError, OSError) as exc:
        raise HTTPException(status_code=422, detail="녹음 파일을 분석하지 못했어요. 원본 형식을 확인해 주세요.") from exc


@app.post("/api/synthesize")
async def synthesize_audio(payload: SynthesizeRequest, request: Request) -> dict[str, Any]:
    identity = require_login(request)
    text = payload.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="읽을 대본을 입력해 주세요.")
    if len(text) > 4000:
        raise HTTPException(status_code=400, detail="한 번에 최대 4,000자까지 만들 수 있어요.")
    profile = get_voice(payload.profileId) if payload.engine == "local" else None
    if payload.engine == "local" and profile is None:
        raise HTTPException(status_code=404, detail="음성 프로필을 찾을 수 없어요.")
    if payload.engine not in {"local", "api"}:
        raise HTTPException(status_code=400, detail="음성 생성 방식을 확인해 주세요.")
    try:
        if payload.engine == "api":
            from personal_api import generate_speech
            settings = workspace_store.settings(identity)
            if not settings.get("key"):
                raise ValueError("내 작업실의 API를 먼저 연결해 주세요. 다른 사람의 키는 사용하지 않습니다.")
            output_path = await generate_speech(settings, text, payload.apiVoiceId, workspace_audio(identity))
        else:
            output_path = await run_in_threadpool(synthesize_with_provider, profile, text, workspace_audio(identity),workspace_store.reading_settings(identity))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not payload.preview:
        remember_render(identity, output_path, text, payload.apiVoiceId if payload.engine == "api" else profile["displayName"], payload.engine)
    temporary = "?temporary=true" if payload.preview else ""
    return {"audioUrl": f"/api/audio/{output_path.name}{temporary}","actualListening":False,"qualityApproved":False}


class ReadingTestRequest(BaseModel):
    profileId: str


@app.post("/api/workspace/reading-test")
async def reading_test(payload: ReadingTestRequest, request: Request) -> dict[str, Any]:
    identity=require_login(request);profile=get_voice(payload.profileId)
    if not profile or profile.get("ownerName")!="아랑":
        raise HTTPException(status_code=400,detail="시험할 아랑 목소리를 먼저 선택해 주세요.")
    text="안녕하세요, 아랑입니다. 평소 궁금했던 질문을 AI와 함께 생각해 보고 싶어서 이 영상을 만들었어요.\n둘 중 하나는 가짜 나일까요?\n응, 먹었어. 지금 바빠서 끊을게.\n편하다는 이유로 상처를 줘도 되는 건 아니잖아요."
    try:
        path=await run_in_threadpool(synthesize_with_provider,profile,text,workspace_audio(identity),workspace_store.reading_settings(identity))
    except Exception as error:raise HTTPException(status_code=503,detail=str(error)) from error
    remember_render(identity,path,text,"아랑 · 읽기 설정 시험 · 미검수","local")
    return {"audioUrl":"/api/audio/"+path.name,"actualListening":False,"qualityApproved":False,"readingSettings":workspace_store.reading_settings(identity)}


@app.post("/api/bridge/synthesize")
async def bridge_synthesize(payload: SynthesizeRequest, request: Request) -> FileResponse:
    identity = require_scene_maker_code(request)
    text = payload.text.strip()
    if not text:
        raise HTTPException(status_code=400, detail="읽을 대본을 입력해 주세요.")
    if len(text) > 4000:
        raise HTTPException(status_code=400, detail="한 장면은 4,000자 이하로 나눠 주세요.")
    profile = get_voice(payload.profileId)
    if profile is None:
        raise HTTPException(status_code=404, detail="음성 프로필을 찾을 수 없어요.")
    try:
        output_path = await run_in_threadpool(synthesize_with_provider, profile, text, workspace_audio(identity),workspace_store.reading_settings(identity))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return FileResponse(
        output_path,
        media_type="audio/wav",
        background=BackgroundTask(delete_generated_audio, output_path),
    )


def delete_generated_audio(path: Path) -> None:
    path.unlink(missing_ok=True)
    path.with_suffix(".json").unlink(missing_ok=True)
    path.with_suffix(".cleanup.json").unlink(missing_ok=True)


@app.get("/api/audio/{audio_name}")
async def get_audio(audio_name: str, request: Request, temporary: bool = False) -> FileResponse:
    identity = require_login(request)
    if Path(audio_name).name != audio_name:
        raise HTTPException(status_code=404, detail="파일을 찾을 수 없어요.")
    path = workspace_audio(identity) / audio_name
    if not path.is_file() and identity == "owner":
        path = OUTPUT_DIR / audio_name  # Preserve access to pre-workspace renders.
    if not path.is_file():
        raise HTTPException(status_code=404, detail="파일을 찾을 수 없어요.")
    quality = path.with_suffix(".quality.json")
    if quality.is_file() and json.loads(quality.read_text(encoding="utf-8")).get("status") == "rejected":
        raise HTTPException(status_code=409, detail="잡음이나 긴 공백 때문에 보류한 음성이에요. 새 검수용 음성을 준비하고 있어요.")
    cleanup = BackgroundTask(delete_generated_audio, path) if temporary else None
    return FileResponse(path, media_type="audio/wav", filename=audio_name, background=cleanup)


if __name__ == "__main__":
    import uvicorn

    print(f"접속 코드: {ACCESS_CODE}")
    host = os.getenv("VOICE_STUDIO_HOST", "127.0.0.1")
    lan_address = os.getenv("VOICE_STUDIO_LAN_ADDRESS", "").strip()
    if host == "127.0.0.1":
        print("이 PC에서는 http://127.0.0.1:8787 에서 열 수 있어요.")
    elif lan_address:
        print(f"집 Wi-Fi 기기에서는 http://{lan_address}:8787 에서 열 수 있어요.")
    else:
        print("네트워크 접속 모드입니다. 신뢰할 수 있는 사설 네트워크에서만 사용하세요.")
    uvicorn.run(app, host=host, port=8787)
