"""Conservative stationary-noise reduction; never resynthesize or retime speech."""
from __future__ import annotations

import hashlib
import io
import json
import os
import shutil
import subprocess
import threading
import uuid
from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.ndimage import uniform_filter, minimum_filter1d, uniform_filter1d
from scipy.signal import stft, istft, butter, sosfiltfilt

REVISION = "gentle-noise-v4"
_lock = threading.Lock()


def read_audio(source: Path, *, always_2d: bool = False) -> tuple[np.ndarray, int]:
    """Decode the original format, keeping its native sample rate and channels."""
    try:
        audio, rate = sf.read(source, dtype="float64", always_2d=always_2d)
    except (RuntimeError, sf.LibsndfileError):
        executable = shutil.which("ffmpeg")
        if not executable:
            candidate = Path(os.environ.get("LOCALAPPDATA", ""))/"Microsoft/WinGet/Links/ffmpeg.exe"
            executable = str(candidate) if candidate.is_file() else None
        if not executable:
            raise ValueError("이 녹음 형식을 읽으려면 FFmpeg가 필요해요.")
        try:
            decoded = subprocess.run(
                [executable, "-v", "error", "-nostdin", "-i", str(source), "-map", "0:a:0",
                 "-vn", "-c:a", "pcm_f32le", "-f", "wav", "pipe:1"],
                capture_output=True, check=True, timeout=60,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            audio, rate = sf.read(io.BytesIO(decoded.stdout), dtype="float64", always_2d=always_2d)
        except (subprocess.SubprocessError, RuntimeError) as exc:
            raise ValueError("녹음 파일을 읽지 못했어요. 재생 가능한 WAV, MP3, M4A 파일인지 확인해 주세요.") from exc
    if audio.size == 0 or not np.isfinite(audio).all():
        raise ValueError("녹음 파일이 비어 있거나 올바르지 않은 소리가 포함되어 있어요.")
    return audio, rate


def reduce_noise(audio: np.ndarray, rate: int) -> tuple[np.ndarray, dict]:
    original = np.asarray(audio, dtype=np.float64)
    channels = original[:, None] if original.ndim == 1 else original
    if len(channels) < 2048 or not np.isfinite(channels).all():
        return original.copy(), {"applied": False, "reason": "short-or-invalid"}
    mono = channels.mean(axis=1)
    size, hop = 1024, 256
    _, _, spectrum = stft(mono, rate, nperseg=size, noverlap=size-hop)
    power = np.abs(spectrum) ** 2
    frame_power = power.sum(axis=0)
    # Learn only from actual low-level interior frames, not padded file edges.
    interior = frame_power[2:-2]
    positive = interior[interior > 1e-14]
    if positive.size < 8:
        return original.copy(), {"applied": False, "reason": "no-noise-estimate"}
    quiet = (frame_power <= np.percentile(positive, 15)) & (frame_power > 1e-14)
    quiet[:2] = quiet[-2:] = False
    if np.count_nonzero(quiet) < 4:
        return original.copy(), {"applied": False, "reason": "no-quiet-frames"}
    # Do not guess a noise profile from continuous speech.
    contrast = float(np.percentile(positive, 80) / np.median(frame_power[quiet]))
    if contrast < 100:
        return original.copy(), {"applied": False, "reason": "speech-without-clear-pauses"}
    noise = np.median(power[:, quiet], axis=1)[:, None]
    ratio = noise / np.maximum(power, 1e-18)
    gain = np.sqrt(np.clip(1 - 1.15 * ratio, 0.0631, 1.0))
    # Speech-bearing bins can lose at most 0.5 dB; only noise-dominated bins
    # receive up to 12 dB attenuation. No EQ, compression, or pitch processing.
    gain = np.where(ratio < 0.1, np.maximum(gain, 10 ** (-0.5/20)), gain)
    gain = uniform_filter(gain, size=(3, 3), mode="nearest")
    cleaned = np.empty_like(channels)
    for channel in range(channels.shape[1]):
        _, _, band = stft(channels[:, channel], rate, nperseg=size, noverlap=size-hop)
        _, reconstructed = istft(band * gain, rate, nperseg=size, noverlap=size-hop)
        cleaned[:, channel] = reconstructed[:len(channels)]
    # Discard filtering if the spoken waveform moves materially away from source.
    frame = max(1, int(rate * .025))
    count = len(mono) // frame
    energy = np.sqrt(np.mean(mono[:count*frame].reshape(count, frame)**2, axis=1))
    # Lower the room floor in clearly quiet pauses. Keep 125 ms around every
    # audible frame, then fade over 50 ms so consonants and breaths are retained.
    quiet_limit = min(.0025, max(.0001, float(np.percentile(energy, 15)) * 2))
    pause = minimum_filter1d((energy < quiet_limit).astype(float), size=11, mode="nearest")
    pause = np.repeat(pause, frame)
    pause = np.pad(pause, (0, len(mono)-len(pause)), mode="edge")
    pause = uniform_filter1d(pause, size=max(1, int(rate*.05)), mode="nearest")
    cleaned *= (1 - pause * (1 - 10**(-12/20)))[:, None]
    # Some local clone renders add a high, breath-like bed between words even
    # when the original recording is quiet. Detect that bed in genuine pauses
    # before applying a mild high-frequency roll-off. Clean references and
    # continuous speech are left alone; this is not a global voice EQ.
    quiet_frames = energy < .005
    hiss_detected = False
    hiss_before = 0.0
    hiss_after = 0.0
    if rate >= 22000 and np.count_nonzero(quiet_frames) >= 8:
        high = sosfiltfilt(butter(4, (5000, min(10000, rate*.45)),
                                    btype="bandpass", fs=rate, output="sos"), mono)
        high_energy = np.sqrt(np.mean(high[:count*frame].reshape(count, frame)**2, axis=1))
        hiss_before = float(np.median(high_energy[quiet_frames]))
        quiet_level = float(np.median(energy[quiet_frames]))
        hiss_detected = hiss_before > .0006 and hiss_before > quiet_level*.25
        if hiss_detected:
            lowpass = butter(4, 6800, btype="lowpass", fs=rate, output="sos")
            cleaned = sosfiltfilt(lowpass, cleaned, axis=0)
            after_high = sosfiltfilt(butter(4, (5000, min(10000, rate*.45)),
                                              btype="bandpass", fs=rate, output="sos"),
                                      cleaned.mean(axis=1))
            after_energy = np.sqrt(np.mean(after_high[:count*frame].reshape(count, frame)**2, axis=1))
            hiss_after = float(np.median(after_energy[quiet_frames]))
    # Spectral reconstruction can overshoot full scale at isolated source peaks.
    # Restore those exact source samples instead of normalizing the whole voice.
    restore_peak = (np.abs(cleaned) > 1.) & (np.abs(cleaned) > np.abs(channels))
    cleaned[restore_peak] = channels[restore_peak]
    speech = np.repeat(energy > max(.006, np.percentile(energy, 65)), frame)
    speech = np.pad(speech, (0, len(mono)-len(speech)))
    before, after = channels[speech].reshape(-1), cleaned[speech].reshape(-1)
    cosine = float(np.dot(before, after) / max(1e-20, np.linalg.norm(before)*np.linalg.norm(after)))
    delta_db = float(20*np.log10(max(1e-12, np.linalg.norm(after))/max(1e-12, np.linalg.norm(before))))
    accepted = (cosine >= (.97 if hiss_detected else .999)
                and abs(delta_db) <= .3 and np.isfinite(cleaned).all()
                and np.max(np.abs(cleaned)) <= max(1., np.max(np.abs(channels))) + .005)
    quiet_samples = np.repeat(energy <= np.percentile(energy[energy > 0], 15), frame)
    quiet_samples = np.pad(quiet_samples, (0, len(mono)-len(quiet_samples)))
    quiet_before = np.linalg.norm(channels[quiet_samples])
    quiet_after = np.linalg.norm(cleaned[quiet_samples])
    reduction = float(20*np.log10(max(1e-12, quiet_before)/max(1e-12, quiet_after)))
    report = {"applied": bool(accepted), "speechWaveformCosine": round(cosine, 8),
              "speechLevelChangeDb": round(delta_db, 4), "quietReductionDb": round(reduction, 3),
              "sampleRate": rate, "frames": len(channels), "channels": channels.shape[1],
              "restoredPeakSamples": int(np.count_nonzero(restore_peak)),
              "pitchShift": False, "timeStretch": False, "resynthesis": False}
    report.update({"highFrequencyHissDetected": hiss_detected,
                   "quietHighBandRmsBefore": round(hiss_before, 7),
                   "quietHighBandRmsAfter": round(hiss_after, 7)})
    result = cleaned if accepted else channels
    return (result[:, 0] if original.ndim == 1 else result), report


def cleaned_copy(source: Path, directory: Path) -> tuple[Path, dict]:
    """Content-keyed, atomic cache. Source and profile metadata remain untouched."""
    source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
    key = hashlib.sha256(f"{REVISION}:{source_hash}".encode()).hexdigest()[:20]
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / f"{source.stem}-{key}.wav"
    info = target.with_suffix(".cleanup.json")
    with _lock:
        if target.is_file() and info.is_file():
            return target, json.loads(info.read_text(encoding="utf-8"))
        audio, rate = read_audio(source)
        cleaned, report = reduce_noise(audio, rate)
        report.update({"revision": REVISION, "sourceSha256": source_hash,
                       "sourceName": source.name})
        # Floating WAV avoids clipping or quantizing the source to fewer bits.
        temporary = target.with_name(f".{target.stem}-{uuid.uuid4().hex}.tmp")
        try:
            sf.write(temporary, cleaned, rate, format="WAV", subtype="FLOAT")
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)
        info.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return target, report


def recording_quality(source: Path, directory: Path) -> dict:
    cleaned, processing = cleaned_copy(source, directory)
    audio, rate = read_audio(source, always_2d=True)
    mono = audio.mean(axis=1)
    frame = max(1, int(rate*.025))
    blocks = len(mono)//frame
    energies = np.sqrt(np.mean(mono[:blocks*frame].reshape(blocks, frame)**2, axis=1)) if blocks else np.array([0.])
    db = lambda value: round(float(20*np.log10(max(float(value), 1e-9))), 1)
    clipped = int(np.count_nonzero(np.abs(audio) >= .9999))
    messages = []
    if len(audio)/rate < 15:
        messages.append("녹음이 짧아요. 새 녹음은 30초 이상이면 목소리를 더 안정적으로 학습할 수 있어요.")
    if clipped:
        messages.append("최대 음량에 닿은 샘플이 있어요. 왜곡 여부는 원본을 들어 확인해야 하며, 잘린 소리는 잡음 제거만으로 복원되지 않아요.")
    if np.percentile(energies, 10) > .0056:
        messages.append("조용한 부분의 레벨이 높아요. 배경 잡음인지 작은 말소리인지는 비교해서 들어보세요.")
    if not processing.get("applied"):
        messages.append("말소리 보존 조건을 충족하지 않아 원본을 유지했어요.")
    # A small, common-scale waveform is display data, not an audio-quality score.
    def waveform(values):
        return [round(float(np.max(np.abs(part))), 4) if len(part) else 0 for part in np.array_split(values, 240)]
    processed, _ = sf.read(cleaned, always_2d=True)
    return {"durationSeconds": round(len(audio)/rate, 2), "sampleRate": rate,
            "channels": audio.shape[1], "peakDbfs": db(np.max(np.abs(audio))),
            "quietLevelDbfs": db(np.percentile(energies, 10)),
            "clippedSamples": clipped, "messages": messages,
            "processing": processing, "originalPreserved": True,
            "waveformOriginal": waveform(mono), "waveformClean": waveform(processed.mean(axis=1))}
