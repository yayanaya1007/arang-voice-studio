"""Unmodified official Qwen Base weights; all confirmed owner recordings are references.

This creates an in-memory clone prompt only. It never trains or writes model weights.
"""
from __future__ import annotations
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import threading
import numpy as np
import soundfile as sf
from profile_voice_engine import _engine

_lock=threading.Lock()
_cache={}
ENGINE_ID='official-qwen3-tts-0.6b-base-owner-references-v2'

def owner_recordings(app_root: Path, voice_dir: Path):
    root=voice_dir.parent
    entries=[(p,voice_dir) for p in json.loads((root/'profiles.json').read_text(encoding='utf-8'))]
    for metadata in sorted((root/'archived-profiles').glob('*/profile.json')):
        entry=json.loads(metadata.read_text(encoding='utf-8'))
        folder=metadata.parent if (metadata.parent/entry.get('audioFile','')).is_file() else voice_dir
        entries.append((entry,folder))
    for metadata in sorted((root/'arang-references').glob('*/profile.json')):
        entries.append((json.loads(metadata.read_text(encoding='utf-8')),metadata.parent))
    seen=set();sources=[]
    for entry,folder in entries:
        if entry.get('ownerName')!='아랑':continue
        name=entry.get('audioFile','')
        if not name or Path(name).name!=name:raise ValueError('Invalid owner reference path')
        path=folder/name
        if not path.is_file() or not entry.get('referenceText','').strip():
            raise RuntimeError('아랑 원본 녹음이나 녹음 대본이 빠져 있어 생성을 멈췄어요.')
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        if digest in seen:continue
        seen.add(digest)
        sources.append({'id':entry['id'],'name':entry['displayName'],'path':str(path.resolve()),
                        'sha256':digest,'text':entry['referenceText']})
    if not sources:raise RuntimeError('아랑 원본 녹음이 없어요.')
    return sources

def synthesize_owner(text,profile,app_root,voice_dir):
    import torch
    sources=owner_recordings(app_root,voice_dir)
    key=tuple((s['id'],s['sha256'],hashlib.sha256(s['text'].encode()).hexdigest()) for s in sources)
    with _lock:
        model=_engine(app_root)
        prompts=_cache.get(key)
        if prompts is None:
            recordings=[]
            for source in sources:
                waveform,rate=sf.read(source['path'],dtype='float32')
                if waveform.ndim>1:waveform=waveform.mean(axis=1)
                recordings.append((waveform,rate))
            prompts=model.create_voice_clone_prompt(ref_audio=recordings,ref_text=[s['text'] for s in sources])
            if len(prompts)!=len(sources):raise RuntimeError('일부 원녹음이 참조에 연결되지 않았어요.')
            _cache.clear();_cache[key]=prompts
        # Every distinct original contributes equally; no outlier recording is dropped.
        # Qwen's speaker encoder returns unnormalized vectors. Unit normalization
        # destroys the amplitude scale expected by its talker and can yield silence.
        embeddings=torch.stack([p.ref_spk_embedding.float() for p in prompts])
        pooled=embeddings.mean(dim=0)
        index=next((i for i,s in enumerate(sources) if s['id']==profile['id']),0)
        template=prompts[index]
        prompt=replace(template,ref_spk_embedding=pooled.to(device=template.ref_spk_embedding.device,dtype=template.ref_spk_embedding.dtype))
        budget=min(4096,max(384,len(text)*12))
        torch.manual_seed(20261107+sum(map(ord,text)))
        waveforms,rate=model.generate_voice_clone(
            text=text,language='Korean',voice_clone_prompt=[prompt],non_streaming_mode=True,
            do_sample=True,temperature=.65,top_p=.85,top_k=40,repetition_penalty=1.08,
            subtalker_dosample=True,subtalker_temperature=.7,subtalker_top_p=.9,max_new_tokens=budget,
        )
        waveform=np.asarray(waveforms[0],dtype=np.float32).reshape(-1)
        if not len(waveform) or not np.isfinite(waveform).all():raise RuntimeError('정상 음성이 생성되지 않았어요.')
        if float(np.sqrt(np.mean(waveform.astype(np.float64)**2))) < .001:
            raise RuntimeError('생성 결과에서 정상적인 말소리가 확인되지 않아 내보내지 않았어요.')
        if len(waveform)/rate >= (budget-8)/12:
            raise RuntimeError('문장이 끝나기 전에 생성 한도에 도달했어요. 잘린 결과는 내보내지 않았습니다.')
        peak=float(np.max(np.abs(waveform)))
        if peak>1:waveform=waveform/peak*.98
        audit={'engine':ENGINE_ID,'modelPath':str(voice_dir.parent/'private-model/models/Qwen3-TTS-12Hz-0.6B-Base'),
               'training':False,'personalCheckpoint':False,'referenceCount':len(sources),
               'references':[{k:s[k] for k in ('id','name','path','sha256')} for s in sources],
               'prosodyReferenceId':sources[index]['id'],'audioListening':'unverified'}
        return waveform,int(rate),audit
